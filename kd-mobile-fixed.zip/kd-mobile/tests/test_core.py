import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import core

D = ["kemono.cr", "coomer.st", "pawchive.pw"]


def test_parse_post():
    t = core.parse_url("https://kemono.cr/patreon/user/123/post/456", D)
    assert (t.service, t.creator_id, t.post_id) == ("patreon", "123", "456")
    assert t.config["api_base"] == "https://kemono.cr/api/v1"


def test_parse_creator_with_query():
    t = core.parse_url("https://coomer.st/onlyfans/user/abc?o=50", D)
    assert t.post_id is None and t.config["domain"] == "coomer.st"


def test_parse_bad():
    try:
        core.parse_url("https://kemono.cr/", D)
        assert False
    except ValueError:
        pass


def test_pawchive_file_host():
    cfg = core.build_config("pawchive.pw")
    url = core.clean_file_url("/ab/cd/file.jpg", cfg)
    assert url == "https://file.pawchive.pw/data/ab/cd/file.jpg"


def test_extract_files():
    cfg = core.build_config("kemono.cr")
    post = {
        "file": {"name": "a.png", "path": "/aa/a.png"},
        "attachments": [{"name": "b.zip", "path": "/bb/b.zip"}, {"name": "c.exe", "path": "/c.exe"}],
        "content": '<p><img src="/dd/d.jpg"></p>',
    }
    out = core.extract_files(post, cfg, core.DEFAULT_EXTENSIONS)
    names = [n for n, _ in out]
    assert names == ["a.png", "b.zip", "d.jpg"]
    assert out[0][1] == "https://kemono.cr/aa/a.png?f=a.png"


def test_sanitize():
    assert core.sanitize_filename('a/b:c*?"d e') == "a_b_c_d_e"
    assert core.sanitize_filename("") == "unnamed"
